QalamAI — Static Landing (No build)

How to put this online (Vercel, 2 minutes):
1) Go to https://vercel.com -> New Project -> Import -> Upload.
2) Select the ZIP of this folder.
3) Deploy. You’ll get a public link like https://qalamai.vercel.app

Optional:
- Edit index.html -> Waitlist form `action` to your Formspree/Google Forms endpoint.
- Replace the square logo block with your SVG/PNG.
- Netlify also works: drag-and-drop the folder in the Netlify dashboard.

Files:
- index.html — the whole site (Tailwind via CDN)
- README.txt — these instructions
